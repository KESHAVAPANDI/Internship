import cv2
import numpy as np
import os
from matplotlib import pyplot as plt

def detect_and_keep_text(input_image_path, output_image_path):
    if not os.path.exists(input_image_path):
        raise FileNotFoundError(f"Input image file not found at {input_image_path}")

    # Read the image in grayscale
    image = cv2.imread(input_image_path, cv2.IMREAD_GRAYSCALE)
    
    # Apply adaptive thresholding to create a binary image
    binary_image = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                         cv2.THRESH_BINARY_INV, 11, 2)
    
    # Define kernels for morphological operations
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 1))
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 30))
    
    # Remove horizontal lines
    horizontal_lines = cv2.morphologyEx(binary_image, cv2.MORPH_OPEN, horizontal_kernel, iterations=1)
    binary_image_no_horizontal = cv2.bitwise_and(binary_image, cv2.bitwise_not(horizontal_lines))

    # Remove vertical lines
    vertical_lines = cv2.morphologyEx(binary_image_no_horizontal, cv2.MORPH_OPEN, vertical_kernel, iterations=1)
    binary_image_clean = cv2.bitwise_and(binary_image_no_horizontal, cv2.bitwise_not(vertical_lines))
    
    # Further clean up any small remaining lines using morphological closing
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    binary_image_clean = cv2.morphologyEx(binary_image_clean, cv2.MORPH_CLOSE, kernel, iterations=1)
    
    # Find contours of the text regions
    contours, _ = cv2.findContours(binary_image_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Create a blank white image
    result_image = np.ones_like(image) * 255
    
    # Copy the text regions from the original image to the blank image
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w > 10 and h > 10:  # Filter out very small contours that are unlikely to be text
            # Extract text region from the original image
            text_region = image[y:y+h, x:x+w]
            # Place the text region on the result image at the same location
            result_image[y:y+h, x:x+w] = text_region
    
    # Save the result image
    cv2.imwrite(output_image_path, result_image)
    
    # Show the result image
    plt.imshow(result_image, cmap='gray')
    plt.title('Processed Image')
    plt.axis('off')
    plt.show()

def main(input_image_path, output_image_path):
    detect_and_keep_text(input_image_path, output_image_path)

# Example usage with provided paths
input_image_path = r"C:\Users\kesha\OneDrive\Desktop\forms\im4.jpg"
output_image_path = r"C:\Users\kesha\OneDrive\Desktop\check5.png"

main(input_image_path, output_image_path)
